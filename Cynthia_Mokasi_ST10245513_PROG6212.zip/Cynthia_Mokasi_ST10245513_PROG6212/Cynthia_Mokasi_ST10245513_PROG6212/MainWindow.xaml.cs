﻿using customLibrary;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Cynthia_Mokasi_ST10245513_PROG6212
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {

            InitializeComponent();


            string headings = "# of Weeks   |    Start Date    |  Module Code   |  Module Name  |  # of Credits  | Class Hours Per Week   |   self-study hours   | remaining hours";

            messageBox.Items.Add(headings);
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrEmpty(numberOfWeeksPerSemesterTxt.Text)
                || !string.IsNullOrEmpty(startDateTxt.Text)
                || !string.IsNullOrEmpty(numberOfWeeksPerSemesterTxt.Text)
                || !string.IsNullOrEmpty(codeTxt1.Text)
                || !string.IsNullOrEmpty(hoursPentPerWeek.Text)
                || !string.IsNullOrEmpty(nameTxt1.Text)
                || !string.IsNullOrEmpty(numberOfCreditsTxt1.Text)
                || !string.IsNullOrEmpty(classHoursPerWeekTxt1.Text))
            {
                UserData userData = new UserData();
                User user = new User()
                {
                    StartDate = startDateTxt.Text,
                    NumberOfWeeks = int.Parse(numberOfWeeksPerSemesterTxt.Text),
                    Module = new Module()
                    {
                        //class hours per week
                        ClassHoursPerWeek = int.Parse(classHoursPerWeekTxt1.Text),
                        Code = codeTxt1.Text,
                        Name = nameTxt1.Text,
                        NumberOfCredits = int.Parse(numberOfCreditsTxt1.Text),
                        HoursSpentPerWeek = int.Parse(hoursPentPerWeek.Text)
                    }
                };

                userData.AddUser(user);
                List<User> users = userData.GetUsers();


                foreach (User item in users)
                {
                    double selfStudyHours = userData.CalculateSelfStudyHours(item.Module.NumberOfCredits, item.NumberOfWeeks, item.Module.ClassHoursPerWeek);
                    string message = $"{ item.NumberOfWeeks}                    { item.StartDate}             { item.Module.Code}        " +
                                      $"{ item.Module.Name}                            { item.Module.NumberOfCredits}                         { item.Module.ClassHoursPerWeek}                 " +
                                      $"                  { selfStudyHours }                      {userData.CalculateRemainingHours(selfStudyHours, int.Parse(hoursPentPerWeek.Text))}";

                    messageBox.Items.Add(
                        message
                    );
                }
            }
            else
            {
                MessageBox.Show("Fields may not be null or empty");
            }

        }

        private void messageBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
