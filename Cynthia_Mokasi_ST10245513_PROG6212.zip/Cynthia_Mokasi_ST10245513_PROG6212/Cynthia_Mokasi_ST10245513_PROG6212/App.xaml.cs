﻿using System.Windows;

namespace Cynthia_Mokasi_ST10245513_PROG6212
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
