Programming2B Task 1 Mokasi Cynthia

Readme File.

Steps to open project.

1. Download Visual Studio 2019.
2. Open Visual Studio 2019.
3. Extract a file named Task 1 Programming followed by student number.
4. Open and view that file, thats where you will find the code.
5. Comments will guide you on where to find a specifc code.
6. You will see a green Start button which is a run button.
7. You will press that button then the code will start to run.
8. The user interface will guide you on what to do.
9. The user interface is very user friendly I can assure that for the marker.




