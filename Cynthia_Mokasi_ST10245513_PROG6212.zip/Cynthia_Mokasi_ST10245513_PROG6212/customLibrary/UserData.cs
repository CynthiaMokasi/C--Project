﻿using System.Collections.Generic;
using System.Linq;

namespace customLibrary
{
    public class UserData
    {
        List<User> users = new List<User>();
        // calculations for  number of credits, number of weeks and class hours per week
        public double CalculateSelfStudyHours(int numberOfCredits, int numberOfWeeks, int classHoursPerWeek)
        {
            double selfStudyHours = ((numberOfCredits * 10) / numberOfWeeks) - classHoursPerWeek;
            return selfStudyHours;
        }

        public double CalculateRemainingHours(double selfStudyHours, int hoursSpentPerWeek)
        {
            double remainingHours = selfStudyHours - hoursSpentPerWeek;
            return remainingHours;
        }
        // start to add return statement
        public bool AddUser(User user)
        {
            // return ifis true or not
            users.Add(user);
            return true;

        }

        public List<User> GetUsers()
        {
            var result = from u in users
                         select u;
            return result.ToList();
        }
    }
}
