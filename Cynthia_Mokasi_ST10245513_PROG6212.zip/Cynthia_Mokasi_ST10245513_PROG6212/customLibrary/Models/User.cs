﻿namespace customLibrary
{
    // getters and setters
    public class User
    {
        public int NumberOfWeeks { get; set; }
        public string StartDate { get; set; }
        public Module Module { get; set; }

    }
}
