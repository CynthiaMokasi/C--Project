﻿using System;

namespace customLibrary
{
    //declariing a modules with getters and setters
    public class Module
    {
        public String Code { get; set; }
        public String Name { get; set; }
        public int NumberOfCredits { get; set; }
        public int ClassHoursPerWeek { get; set; }
        public int HoursSpentPerWeek { get; set; }
    }
}
