Programming2A Part 2 Mokasi Cynthia

Readme File.

Steps to open project.

1. Download Visual Studio 2019.
2. Open Visual Studio 2019.
3. Extract a file named Part 1 Programming followed by student number.
4. Open and view that file, thats where you will find the code.
5. Comments will guide you on where to find a specifc code.
6. You will see a green Start button which is a run button.
7. You will press that button then the code will start to run.
8. The user interface will guide you on what to do.
9. The user interface is very user friendly I can assure that for the marker.


What I have improved from Task 1

1. expenses class is abstract as instructed.
2. I used a generic list to store expenses not an array
3. I also chendged my calculation since it was not working proper or accordingly in part 1
4. My code is no longer breaking is you enter letters instead of numbers

What I've eadded

1. I created vehicleLoan class as mentioned on part 2
2. I've added more commnects from previous class an the current class i've created
3. Calculations work proper
4. My expenses display is in descending order. 
5. Delegate to notify the user when expences exceed 75% of the income






