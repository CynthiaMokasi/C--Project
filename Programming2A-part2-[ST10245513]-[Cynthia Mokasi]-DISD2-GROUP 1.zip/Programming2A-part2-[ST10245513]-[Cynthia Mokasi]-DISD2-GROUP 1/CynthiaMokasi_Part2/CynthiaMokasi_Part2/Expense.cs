﻿
namespace CynthiaMokasi_Part1
{
    public class Expense
    {
        //get; set expense
        public double amount { get; set; }
        public string expenseCategory { get; set; }
    }
}
