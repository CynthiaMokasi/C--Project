﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CynthiaMokasi_Part1
{
    //This is the user class, which ask the user to enter the input or information
    public class User
    {
        private double grossMonthlyIncome { get; set; }
        private double monthlyTaxAmount { get; set; }
        private List<Expense> expenses { get; set; }

        public User()
        {
            expenses = new List<Expense>();
        }

        public void start()
        {
            double homeLoanRepayment = 0;
            double vehicleLoanRepayment = 0;
            double availableMonthlyAmount = 0;

            //the user need to enter the montly amount before deductions
            Console.WriteLine("Enter your gross monthly income before deductions?");
            grossMonthlyIncome = checkIfNotAdouble(Console.ReadLine());


            /* The code below will print the words monthly tax deduction 
             to the screen */
            Console.WriteLine("Enter your estimated monthly tax deducted?");
            monthlyTaxAmount = checkIfNotAdouble(Console.ReadLine());

            //this line is asking the user to chose option between a and d
            Console.WriteLine("Please select (a) to enter an expense, and select (d) once all the expenses are added");
            string option = Console.ReadLine().ToLower();

            while (option != "d")
            {
                // Im using the if else stement
                Console.WriteLine("Enter your amount?");
                double amount = Convert.ToDouble(Console.ReadLine());

                //Simpiwe monthly categories
                Console.WriteLine("Select a category \n" +
                    "1. Groceries\n" +
                    "2.Water and lights\n" +
                    "3.Travel costs\n" +
                    "4.Cellphone and Telephone\n" +
                    "5.Other expenses");
                int category = Convert.ToInt32(Console.ReadLine());
                // I decided to use if else statement 
                if (category == 1)
                {
                    expenses.Add(new Expense { amount = amount, expenseCategory = "grocerries" });
                }
                else if (category == 2)
                {
                    expenses.Add(new Expense { amount = amount, expenseCategory = "Water and lights" });
                }
                else if (category == 3)
                {
                    expenses.Add(new Expense { amount = amount, expenseCategory = "Travel costs" });
                }
                else if (category == 4)
                {
                    expenses.Add(new Expense { amount = amount, expenseCategory = "Cellphone and Telephone" });
                }
                else if (category == 5)
                {
                    expenses.Add(new Expense { amount = amount, expenseCategory = "Other expenses" });
                }

                Console.WriteLine("Please remember to select (d) once all the expenses are added, else enter (a) to continue adding expenses");
                option = Console.ReadLine().ToLower();
            }

            Console.WriteLine("Are you renting or buying? Please enter (r) for renting and (b) for buying");
            string propertyOption = Console.ReadLine().ToLower();

            if (propertyOption == "r")
            {
                Console.WriteLine("Enter the rent Amount?");
                double rentAmount = Convert.ToDouble(Console.ReadLine());

                expenses.Add(new Expense { amount = rentAmount, expenseCategory = "Other expenses" });
            }
            else if (propertyOption == "b")
            {
                Console.WriteLine("Enter the price of the property?");
                double propertyPrice = checkIfNotAdouble(Console.ReadLine()); ;

                //Asiking Simpiwe to enter deposit amunt
                Console.WriteLine("Enter the deposit amount?");
                double deposit = checkIfNotAdouble(Console.ReadLine()); ;

                Console.WriteLine("Enter the interest rate?");
                double interestRate = checkIfNotAdouble(Console.ReadLine()); ;

                //Asking Simpiwe to enter the repayment period
                Console.WriteLine("Enter the repayment period?");
                int repaymentPeriod = Convert.ToInt32(Console.ReadLine());

                HomeLoan homeLoan = new(propertyPrice, deposit, interestRate, repaymentPeriod);

                homeLoanRepayment = homeLoan.calculateRepaymentAmount();

                Console.WriteLine("The monthly home loan repayment is : {0:C2}", homeLoanRepayment);
                expenses.Add(new Expense { amount = homeLoanRepayment, expenseCategory = "Home loan" });

                Console.WriteLine(homeLoan.userAlert(homeLoanRepayment, grossMonthlyIncome));

            }
            // an additional code that is related to vehicleLoans class

            availableMonthlyAmount = calculateAvailableMonthlyAmount();
            Console.WriteLine("Available Monthly Amount is : {0:C2}", availableMonthlyAmount);

            // Here Simpiwe is supposed to chose an option, if he's going to buy a car or not 

            Console.WriteLine("Are you buying a vehicle? Please enter (n) for NO and (y) for YES");
            string vehicleOption = Console.ReadLine().ToLower();
            // i'm using if else statement to get an wanted output

            if (vehicleOption == "n")
            {
                Console.WriteLine("Thank you for using our product, Hope to see you use the software again, Good bye");
            }
            else if (vehicleOption == "y")
            {

                Console.WriteLine("Please enter the car make?");
                string make = Console.ReadLine().ToLower();

                Console.WriteLine("Please enter the car model?");
                string model = Console.ReadLine().ToLower();

                Console.WriteLine("Please enter the purchase price?");
                double purchasePrice = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Please enter the total deposit?");
                double totalDeposit = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Please enter the interest rate in percentage?");
                double interestRate = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Please enter the estimated insurance premium?");
                double insurancePremium = Convert.ToDouble(Console.ReadLine());

                VehicleLoan vehicleLoan = new VehicleLoan(make, model, purchasePrice, totalDeposit, interestRate, insurancePremium);
                vehicleLoanRepayment = vehicleLoan.calculateTotalMonthlyCost();

                expenses.Add(new Expense { amount = vehicleLoanRepayment, expenseCategory = "Vehicle loan" });
                Console.WriteLine("The total monthly cost is : {0:C2}", vehicleLoanRepayment);

                Console.WriteLine(notifyUserIfExpensesExceed75Percent());

                // Expenses display in descending order

                Console.WriteLine("Amount" + "    |    " + " Category");
                Console.WriteLine("------------------------------------");
                displayExpenses();

            }

        }
        //all calculations of Simpiwe
        public double calculateAvailableMonthlyAmount()
        {
            double totalExpense = 0;
            expenses.ForEach(expense =>
            {
                totalExpense += expense.amount;
            });

            double totalAmount = grossMonthlyIncome - (totalExpense + monthlyTaxAmount);

            return totalAmount;
        }

        public double checkIfNotAdouble(string number)
        {
            double value;
            if (!double.TryParse(number, out value))
            {
                Console.WriteLine("The value entered is not a number, Please enter a number");
                value = Convert.ToDouble(Console.ReadLine());
            }

            return value;
        }

        public string notifyUserIfExpensesExceed75Percent()
        {
            double totExpense = 0;
            expenses.ForEach(expense =>
            {
                totExpense += expense.amount;
            });
            //Delegate to notify the user when expences exceed 75 % of the income
            return (totExpense > (0.75 * grossMonthlyIncome)) ? "The total expenses exceed 75% of the gross income" : "";
        }

        public void displayExpenses()
        {
            var sortedList = expenses.OrderByDescending(expense => expense.amount).ToList();

            sortedList.ForEach(item =>
            {
                // C2 to stand for currency
                Console.Write(" {0:C2}", item.amount);
                Console.Write("      " + item.expenseCategory);
                Console.WriteLine();
            });
        }
    }
}
