﻿
namespace CynthiaMokasi_Part1
{
    //this is the rating class
    public class Renting : Expense
    {
    }
}
