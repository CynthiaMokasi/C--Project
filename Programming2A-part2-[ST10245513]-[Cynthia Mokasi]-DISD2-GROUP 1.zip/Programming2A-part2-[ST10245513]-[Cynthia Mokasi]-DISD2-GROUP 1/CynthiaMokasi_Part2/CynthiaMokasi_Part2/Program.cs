﻿namespace CynthiaMokasi_Part1
{
    //this is class program
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User();
            user.start();
        }
    }
}
