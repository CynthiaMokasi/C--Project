﻿
namespace CynthiaMokasi_Part1
{
   //This is a new class i've added which is vehicleLoan, where by it talks about Simpiwe if he wanna buy a car or not 
    public class VehicleLoan : Expense
    {
        private string make { get; set; }
        private string model { get; set; }
        private double purchasePrice { get; set; }
        private double totalDeposit { get; set; }
        private double interestRate { get; set; }
        private double insurancePremium { get; set; }

        public VehicleLoan() { }

        //Method class with getters and setters
        public VehicleLoan(string _make, string _model, double _purchasePrice, double _totalDeposit, double _interestRate, double _insurancePremium)
        {
            make = _make;
            model = _model;
            purchasePrice = _purchasePrice;
            totalDeposit = _totalDeposit;
            interestRate = _interestRate;
            insurancePremium = _insurancePremium;
        }
        // here is the calculation method
        public double calculateTotalMonthlyCost()
        {
            //this are the claculations that are going to calculate the whole amount if Simpiwe going to buy a car
            //and even if he's not going to buy a car
            double repaymentAmount = purchasePrice * (1 + ((interestRate / 100) * (60 / 12)));
            double totalMonthlyCost = (repaymentAmount / 60) + insurancePremium;
            return totalMonthlyCost;
        }


    }
}
