﻿
namespace CynthiaMokasi_Part1
{
    //Homeloan class wxpense
    public class HomeLoan : Expense
    {
        private double deposit { get; set; }
        private double interestRate { get; set; }
        private int repaymentPeriod { get; set; }

        public HomeLoan()
        {

        }
        //homeloan getters nad setters
        public HomeLoan(double a, double d, double i, int r)
        {
            amount = a;
            deposit = d;
            interestRate = i;
            repaymentPeriod = r;
        }
        //homeloan method and calculations
        public double calculateRepaymentAmount()
        {
            double repaymentAmount = amount * (1 + ((interestRate / 100) * (repaymentPeriod / 12)));
            return repaymentAmount / repaymentPeriod;
        }

        public string userAlert(double repaymentAmount, double grossSalary)
        {
            return (repaymentAmount > (0.75 * grossSalary)) ? "unlikely" : "";
        }
    }
}
